import praw
srno = 1;
reddit = praw.Reddit(client_id="f4QT47zgSpuueA",
                    client_secret="Cr_qLwp-0OHDBdSxnilAdO_hChA", user_agent="My_Agent")
for submission in reddit.subreddit('trendingsubreddits').hot(limit=104):
    sreddits = submission.title.split(' ',4)[4]
    rtitle = submission.title.split(' ',4)[3]
    #print(rtitle)
    sredditraw = sreddits.split(' ',4)
    print(sredditraw)
    for sredditnames in sredditraw:
        f= open("rurl.txt","a+")
        formatted = "https://wwww.reddit.com"+sredditnames+"\n"
        f.write(formatted)
        print(formatted)
        f.close() 
    #print("-------")
    lines_seen = set() # holds lines already seen
with open("redditurl.txt", "w") as output_file:
	for each_line in open("rurl.txt", "r"):
	    if each_line not in lines_seen: # check if line is not duplicate
	        output_file.write(each_line)
	        lines_seen.add(each_line)